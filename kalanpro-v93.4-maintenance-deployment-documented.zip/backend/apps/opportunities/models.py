from __future__ import annotations

from django.conf import settings
from django.db import models
from django.utils import timezone
from django.utils.text import slugify


class EmployerProfile(models.Model):
    class Status(models.TextChoices):
        PENDING = "pending", "En attente"
        APPROVED = "approved", "Approuvé"
        REJECTED = "rejected", "Refusé"
        SUSPENDED = "suspended", "Suspendu"

    class CompanySize(models.TextChoices):
        SOLO = "solo", "Indépendant"
        MICRO = "1-10", "1–10"
        SMALL = "11-50", "11–50"
        MEDIUM = "51-200", "51–200"
        LARGE = "201-1000", "201–1000"
        ENTERPRISE = "1000+", "1000+"

    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="employer_profile")
    company_name = models.CharField(max_length=180)
    slug = models.SlugField(max_length=200, unique=True, blank=True)
    description = models.TextField(blank=True)
    tagline = models.CharField(max_length=180, blank=True)
    industry = models.CharField(max_length=140, blank=True)
    company_size = models.CharField(max_length=20, choices=CompanySize.choices, blank=True)
    website_url = models.URLField(blank=True)
    linkedin_url = models.URLField(blank=True)
    contact_email = models.EmailField(blank=True)
    founded_year = models.PositiveSmallIntegerField(null=True, blank=True)
    brand_color = models.CharField(max_length=7, default="#ff5a1f", blank=True)
    logo = models.ImageField(upload_to="employers/logos/%Y/%m/", blank=True, null=True)
    banner = models.ImageField(upload_to="employers/banners/%Y/%m/", blank=True, null=True)
    values = models.JSONField(default=list, blank=True)
    benefits = models.JSONField(default=list, blank=True)
    hiring_regions = models.JSONField(default=list, blank=True)
    country = models.CharField(max_length=100)
    city = models.CharField(max_length=120, blank=True)

    class VerificationStatus(models.TextChoices):
        UNVERIFIED = "unverified", "Non vérifiée"
        PENDING = "pending", "Vérification en cours"
        VERIFIED = "verified", "Vérifiée"
        REJECTED = "rejected", "Vérification refusée"

    legal_name = models.CharField(max_length=220, blank=True)
    registration_number = models.CharField(max_length=120, blank=True)
    registration_country = models.CharField(max_length=100, blank=True)
    verification_document = models.FileField(upload_to="employers/verification/%Y/%m/", blank=True, null=True)
    verification_status = models.CharField(
        max_length=20, choices=VerificationStatus.choices, default=VerificationStatus.UNVERIFIED, db_index=True
    )
    verification_note = models.TextField(blank=True)
    verification_submitted_at = models.DateTimeField(null=True, blank=True)
    identity_verified_at = models.DateTimeField(null=True, blank=True)
    identity_verified_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="identity_verified_employer_profiles",
    )

    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING, db_index=True)
    review_note = models.TextField(blank=True)
    reviewed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="reviewed_employer_profiles",
    )
    reviewed_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["company_name"]
        indexes = [models.Index(fields=["status", "created_at"], name="opp_emp_status_created_idx")]

    def save(self, *args, **kwargs):
        if not self.slug:
            base = slugify(self.company_name)[:180] or "entreprise"
            candidate = base
            n = 1
            while EmployerProfile.objects.filter(slug=candidate).exclude(pk=self.pk).exists():
                n += 1
                candidate = f"{base}-{n}"
            self.slug = candidate
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.company_name} · {self.get_status_display()}"


class CandidateProfile(models.Model):
    class Availability(models.TextChoices):
        IMMEDIATE = "immediate", "Disponible immédiatement"
        TWO_WEEKS = "2_weeks", "Sous 2 semaines"
        ONE_MONTH = "1_month", "Sous 1 mois"
        OPEN = "open", "À l'écoute"
        UNAVAILABLE = "unavailable", "Indisponible"

    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="candidate_profile")
    headline = models.CharField(max_length=180, blank=True)
    summary = models.TextField(blank=True)
    skills = models.JSONField(default=list, blank=True)
    desired_roles = models.JSONField(default=list, blank=True)
    preferred_kinds = models.JSONField(default=list, blank=True)
    preferred_work_modes = models.JSONField(default=list, blank=True)
    preferred_countries = models.JSONField(default=list, blank=True)
    minimum_salary = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    salary_currency = models.CharField(max_length=3, default="EUR")
    availability = models.CharField(max_length=20, choices=Availability.choices, default=Availability.OPEN)
    years_experience = models.PositiveSmallIntegerField(default=0)
    resume = models.FileField(upload_to="opportunities/resumes/%Y/%m/", blank=True, null=True)
    is_searchable = models.BooleanField(default=False, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-updated_at"]
        indexes = [models.Index(fields=["is_searchable", "-updated_at"], name="opp_candidate_search_idx")]

    def save(self, *args, **kwargs):
        previously_searchable = False
        if self.pk:
            previously_searchable = bool(
                CandidateProfile.objects.filter(pk=self.pk).values_list("is_searchable", flat=True).first()
            )
        super().save(*args, **kwargs)
        if previously_searchable and not self.is_searchable:
            # La sortie volontaire du vivier doit révoquer immédiatement les favoris
            # recruteur persistants ; aucun bookmark ne doit contourner l'opt-out.
            self.recruiter_bookmarks.all().delete()

    def __str__(self):
        return f"Candidat · {self.user}"


class TalentAccessLog(models.Model):
    class AccessType(models.TextChoices):
        PROFILE = "profile", "Consultation du profil"
        BOOKMARK = "bookmark", "Ajout aux favoris"
        APPLICATION = "application", "Consultation via candidature"

    candidate = models.ForeignKey(CandidateProfile, on_delete=models.CASCADE, related_name="access_logs")
    employer = models.ForeignKey(EmployerProfile, on_delete=models.CASCADE, related_name="talent_access_logs")
    recruiter = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="talent_access_logs",
    )
    access_type = models.CharField(max_length=32, choices=AccessType.choices, default=AccessType.PROFILE)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at", "-id"]
        indexes = [
            models.Index(fields=["candidate", "-created_at"], name="opp_taccess_candidate_idx"),
            models.Index(fields=["employer", "-created_at"], name="opp_taccess_employer_idx"),
        ]

    def __str__(self):
        return f"{self.employer.company_name} → {self.candidate.user} ({self.access_type})"


class EmployerEntitlement(models.Model):
    class Kind(models.TextChoices):
        SINGLE_POST = "single_post", "Annonce à l'unité"
        PRO = "pro", "Pro recrutement"
        BUSINESS = "business", "Business"

    employer = models.ForeignKey(EmployerProfile, on_delete=models.CASCADE, related_name="entitlements")
    order = models.OneToOneField(
        "payments.Order", on_delete=models.PROTECT, related_name="employer_entitlement"
    )
    kind = models.CharField(max_length=32, choices=Kind.choices, db_index=True)
    entitlement_key = models.CharField(
        max_length=191, blank=True,
        help_text="Identifiant métier extensible du droit payé ; dimensionné pour les futurs identifiants prestataire.",
    )
    starts_at = models.DateTimeField(null=True, blank=True, db_index=True)
    ends_at = models.DateTimeField(null=True, blank=True, db_index=True)
    revoked_at = models.DateTimeField(null=True, blank=True, db_index=True)
    revocation_reason = models.CharField(max_length=500, blank=True)
    consumed_at = models.DateTimeField(null=True, blank=True)
    consumed_by = models.OneToOneField(
        "Opportunity", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="consumed_single_post_entitlement",
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-starts_at", "-created_at"]
        indexes = [
            models.Index(fields=["employer", "kind", "revoked_at", "starts_at"], name="opp_entitlement_lookup_idx"),
        ]

    @property
    def is_revoked(self):
        return self.revoked_at is not None

    def __str__(self):
        return f"{self.employer.company_name} · {self.kind} · commande {self.order_id}"


class Opportunity(models.Model):
    class Kind(models.TextChoices):
        JOB = "job", "Emploi"
        INTERNSHIP = "internship", "Stage"
        FREELANCE = "freelance", "Freelance"
        MISSION = "mission", "Mission"

    class ContractType(models.TextChoices):
        FULL_TIME = "full_time", "Temps plein"
        PART_TIME = "part_time", "Temps partiel"
        FIXED_TERM = "fixed_term", "CDD"
        PERMANENT = "permanent", "CDI"
        INTERNSHIP = "internship", "Stage"
        FREELANCE = "freelance", "Freelance"
        PROJECT = "project", "Projet / mission"

    class WorkMode(models.TextChoices):
        REMOTE = "remote", "À distance"
        HYBRID = "hybrid", "Hybride"
        ONSITE = "onsite", "Sur site"

    class ExperienceLevel(models.TextChoices):
        ENTRY = "entry", "Débutant / premier emploi"
        JUNIOR = "junior", "Junior"
        MID = "mid", "Intermédiaire"
        SENIOR = "senior", "Senior"
        LEAD = "lead", "Lead / management"

    class SalaryPeriod(models.TextChoices):
        HOUR = "hour", "Par heure"
        DAY = "day", "Par jour"
        MONTH = "month", "Par mois"
        YEAR = "year", "Par an"
        PROJECT = "project", "Forfait mission"

    class ApplyMode(models.TextChoices):
        INTERNAL = "internal", "Candidature KalanPro"
        EXTERNAL = "external", "Lien externe"

    class Status(models.TextChoices):
        DRAFT = "draft", "Brouillon"
        PUBLISHED = "published", "Publiée"
        CLOSED = "closed", "Clôturée"
        ARCHIVED = "archived", "Archivée"

    employer = models.ForeignKey(EmployerProfile, on_delete=models.PROTECT, related_name="opportunities")
    title = models.CharField(max_length=220)
    slug = models.SlugField(max_length=240, unique=True, blank=True)
    kind = models.CharField(max_length=20, choices=Kind.choices, default=Kind.JOB, db_index=True)
    contract_type = models.CharField(max_length=20, choices=ContractType.choices, default=ContractType.FULL_TIME)
    work_mode = models.CharField(max_length=20, choices=WorkMode.choices, default=WorkMode.REMOTE, db_index=True)
    experience_level = models.CharField(max_length=20, choices=ExperienceLevel.choices, default=ExperienceLevel.ENTRY)
    description = models.TextField()
    department = models.CharField(max_length=140, blank=True)
    openings = models.PositiveSmallIntegerField(default=1)
    cover_image = models.ImageField(upload_to="opportunities/covers/%Y/%m/", blank=True, null=True)
    responsibilities = models.JSONField(default=list, blank=True)
    requirements = models.JSONField(default=list, blank=True)
    skills_required = models.JSONField(default=list, blank=True)
    skills_optional = models.JSONField(default=list, blank=True)
    screening_questions = models.JSONField(default=list, blank=True)
    country = models.CharField(max_length=100, blank=True, db_index=True)
    city = models.CharField(max_length=120, blank=True)
    remote_worldwide = models.BooleanField(default=False)
    salary_min = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    salary_max = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    salary_currency = models.CharField(max_length=3, default="EUR")
    salary_period = models.CharField(max_length=20, choices=SalaryPeriod.choices, default=SalaryPeriod.MONTH)
    show_salary = models.BooleanField(default=True)
    apply_mode = models.CharField(max_length=20, choices=ApplyMode.choices, default=ApplyMode.INTERNAL)
    external_application_url = models.URLField(blank=True)
    application_deadline = models.DateTimeField(null=True, blank=True, db_index=True)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.DRAFT, db_index=True)
    publication_entitlement = models.ForeignKey(
        EmployerEntitlement, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="published_opportunities",
    )
    featured = models.BooleanField(default=False, db_index=True)
    published_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-featured", "-published_at", "-created_at"]
        indexes = [
            models.Index(fields=["status", "kind", "work_mode", "-published_at"], name="opp_listing_public_idx"),
            models.Index(fields=["employer", "status", "-created_at"], name="opp_listing_employer_idx"),
        ]

    def save(self, *args, **kwargs):
        if not self.slug:
            base = slugify(f"{self.title}-{self.employer.company_name}")[:220] or "opportunite"
            candidate = base
            n = 1
            while Opportunity.objects.filter(slug=candidate).exclude(pk=self.pk).exists():
                n += 1
                candidate = f"{base}-{n}"
            self.slug = candidate
        if self.status == self.Status.PUBLISHED and not self.published_at:
            self.published_at = timezone.now()
        super().save(*args, **kwargs)

    @property
    def is_open(self):
        if self.status != self.Status.PUBLISHED:
            return False
        return not self.application_deadline or self.application_deadline > timezone.now()

    def __str__(self):
        return f"{self.title} · {self.employer.company_name}"


class OpportunityApplication(models.Model):
    class Status(models.TextChoices):
        SUBMITTED = "submitted", "Candidature envoyée"
        REVIEWING = "reviewing", "En cours d'étude"
        SHORTLISTED = "shortlisted", "Présélectionné"
        INTERVIEW = "interview", "Entretien"
        OFFER = "offer", "Offre"
        HIRED = "hired", "Retenu"
        REJECTED = "rejected", "Non retenu"
        WITHDRAWN = "withdrawn", "Retirée"

    opportunity = models.ForeignKey(Opportunity, on_delete=models.PROTECT, related_name="applications")
    candidate = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="opportunity_applications")
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.SUBMITTED, db_index=True)
    cover_letter = models.TextField(blank=True)
    screening_answers = models.JSONField(default=list, blank=True)
    resume_file = models.FileField(upload_to="opportunities/applications/%Y/%m/", blank=True, null=True)
    share_portfolio = models.BooleanField(default=True)
    match_score = models.PositiveSmallIntegerField(default=0)

    # Snapshot professionnel au moment de la candidature.
    candidate_name_snapshot = models.CharField(max_length=220)
    candidate_email_snapshot = models.EmailField()
    country_snapshot = models.CharField(max_length=100, blank=True)
    headline_snapshot = models.CharField(max_length=180, blank=True)
    skills_snapshot = models.JSONField(default=list, blank=True)
    portfolio_snapshot = models.JSONField(default=dict, blank=True)
    certificates_snapshot = models.JSONField(default=list, blank=True)
    verified_projects_snapshot = models.JSONField(default=list, blank=True)

    recruiter_note = models.TextField(blank=True)
    recruiter_rating = models.PositiveSmallIntegerField(default=0)
    recruiter_tags = models.JSONField(default=list, blank=True)
    next_step_at = models.DateTimeField(null=True, blank=True)
    applied_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-applied_at"]
        constraints = [
            models.UniqueConstraint(fields=["opportunity", "candidate"], name="uniq_opportunity_candidate_application"),
        ]
        indexes = [
            models.Index(fields=["opportunity", "status", "-applied_at"], name="opp_app_listing_status_idx"),
            models.Index(fields=["candidate", "status", "-applied_at"], name="opp_app_candidate_status_idx"),
        ]

    def __str__(self):
        return f"{self.candidate} → {self.opportunity}"


class ApplicationHistoryEvent(models.Model):
    application = models.ForeignKey(OpportunityApplication, on_delete=models.CASCADE, related_name="history_events")
    actor = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="recruitment_history_events",
    )
    event_type = models.CharField(max_length=64, db_index=True)
    label = models.CharField(max_length=220)
    metadata = models.JSONField(default=dict, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at", "-id"]
        indexes = [models.Index(fields=["application", "-created_at"], name="opp_app_history_idx")]

    def __str__(self):
        return f"{self.application_id} · {self.event_type}"


class RecruitmentInterview(models.Model):
    class Mode(models.TextChoices):
        VIDEO = "video", "Visioconférence"
        PHONE = "phone", "Téléphone"
        ONSITE = "onsite", "Sur site"

    class Status(models.TextChoices):
        SCHEDULED = "scheduled", "Planifié"
        COMPLETED = "completed", "Terminé"
        CANCELLED = "cancelled", "Annulé"

    application = models.ForeignKey(OpportunityApplication, on_delete=models.CASCADE, related_name="interviews")
    scheduled_at = models.DateTimeField(db_index=True)
    duration_minutes = models.PositiveSmallIntegerField(default=45)
    mode = models.CharField(max_length=20, choices=Mode.choices, default=Mode.VIDEO)
    location_or_url = models.CharField(max_length=500, blank=True)
    candidate_message = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.SCHEDULED, db_index=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="created_recruitment_interviews",
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["scheduled_at", "id"]
        indexes = [models.Index(fields=["application", "status", "scheduled_at"], name="opp_interview_app_idx")]

    def __str__(self):
        return f"Entretien {self.application_id} · {self.scheduled_at}"


class EmploymentOffer(models.Model):
    class Status(models.TextChoices):
        PENDING = "pending", "En attente"
        ACCEPTED = "accepted", "Acceptée"
        DECLINED = "declined", "Refusée"
        WITHDRAWN = "withdrawn", "Retirée"

    application = models.OneToOneField(OpportunityApplication, on_delete=models.CASCADE, related_name="employment_offer")
    title = models.CharField(max_length=220, default="Proposition d'embauche")
    message = models.TextField(blank=True)
    salary_amount = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    salary_currency = models.CharField(max_length=3, default="EUR")
    start_date = models.DateField(null=True, blank=True)
    expires_at = models.DateTimeField(null=True, blank=True, db_index=True)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING, db_index=True)
    responded_at = models.DateTimeField(null=True, blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="created_employment_offers",
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"Offre {self.application_id} · {self.status}"


class TalentBookmark(models.Model):
    employer = models.ForeignKey(EmployerProfile, on_delete=models.CASCADE, related_name="talent_bookmarks")
    talent = models.ForeignKey(CandidateProfile, on_delete=models.CASCADE, related_name="recruiter_bookmarks")
    note = models.TextField(blank=True)
    tags = models.JSONField(default=list, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-updated_at"]
        constraints = [
            models.UniqueConstraint(fields=["employer", "talent"], name="uniq_employer_talent_bookmark"),
        ]
        indexes = [
            models.Index(fields=["employer", "-updated_at"], name="opp_bookmark_employer_idx"),
        ]

    def __str__(self):
        return f"{self.employer.company_name} ★ {self.talent.user}"

class SavedTalentSearch(models.Model):
    employer = models.ForeignKey(EmployerProfile, on_delete=models.CASCADE, related_name="saved_talent_searches")
    name = models.CharField(max_length=120)
    search_text = models.CharField(max_length=180, blank=True)
    country = models.CharField(max_length=100, blank=True)
    availability = models.CharField(max_length=20, choices=CandidateProfile.Availability.choices, blank=True)
    min_experience = models.PositiveSmallIntegerField(default=0)
    opportunity = models.ForeignKey(
        Opportunity, on_delete=models.SET_NULL, null=True, blank=True, related_name="saved_talent_searches"
    )
    min_match_score = models.PositiveSmallIntegerField(default=0)
    alerts_enabled = models.BooleanField(default=True, db_index=True)
    last_checked_at = models.DateTimeField(null=True, blank=True, db_index=True)
    last_checked_candidate_id = models.PositiveBigIntegerField(default=0)
    last_match_count = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-updated_at", "-id"]
        constraints = [
            models.UniqueConstraint(fields=["employer", "name"], name="uniq_employer_saved_talent_search_name"),
            models.CheckConstraint(condition=models.Q(min_match_score__lte=100), name="saved_talent_match_lte_100"),
        ]
        indexes = [
            models.Index(fields=["employer", "alerts_enabled", "-updated_at"], name="opp_saved_search_alert_idx"),
        ]

    def __str__(self):
        return f"{self.employer.company_name} · {self.name}"


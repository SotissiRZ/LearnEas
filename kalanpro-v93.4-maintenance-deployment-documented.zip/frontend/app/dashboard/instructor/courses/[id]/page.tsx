"use client";
import { useParams } from "next/navigation";

import { useEffect, useState, useCallback } from "react";
import { PlusCircle, Trash2, PlayCircle, FileText, Eye, EyeOff, Loader2, Upload, Link as LinkIcon, AlertCircle, RefreshCw } from "lucide-react";
import { api, apiUploadWithProgress, ApiError } from "@/lib/api";
import { uploadLessonVideoMultipart, DirectUploadCapabilities } from "@/lib/directMultipartUpload";
import { Course } from "@/types";
import { useAuthGuard } from "@/hooks/useAuthGuard";
import GuardScreen from "@/components/ui/GuardScreen";
import UploadProgressBar from "@/components/ui/UploadProgressBar";
import PdfViewer from "@/components/ui/PdfViewer";
import VideoPlayer from "@/components/ui/VideoPlayer";

const MAX_VIDEO_UPLOAD_MB = Number(process.env.NEXT_PUBLIC_MAX_VIDEO_UPLOAD_MB || "2048");
const MAX_VIDEO_UPLOAD_BYTES = MAX_VIDEO_UPLOAD_MB * 1024 * 1024;
const ALLOWED_VIDEO_EXTENSIONS = [".mp4", ".webm", ".mov", ".m4v"];

function extensionOf(name: string) {
  const idx = name.lastIndexOf(".");
  return idx >= 0 ? name.slice(idx).toLowerCase() : "";
}

export default function ManageCoursePage() { const params = useParams<{ id: string }>();
  const { ready } = useAuthGuard({ roles: ["instructor", "admin"], redirectTo: "/dashboard/instructor" });
  const [course, setCourse] = useState<Course | null>(null);
  const [loading, setLoading] = useState(true);
  const [newSectionTitle, setNewSectionTitle] = useState("");
  const [publishing, setPublishing] = useState(false);
  const [videoPreview, setVideoPreview] = useState<{src:string; title:string; subtitles?:string|null; hls?:string|null; audioHls?:string|null; variants?:Array<{height:number;width?:number;bandwidth?:number}>; streamingStatus?:string} | null>(null);
  const [streamingBusy, setStreamingBusy] = useState<number | null>(null);

  const load = useCallback(async () => {
    const list = await api.get<{ results: Course[] } | Course[]>("/catalog/courses/my_courses/");
    const arr: Course[] = (list as any).results || (list as any);
    const found = arr.find((c) => c.id === Number(params.id));
    if (found) {
      const detail = await api.get<Course>(`/catalog/courses/${found.slug}/`);
      setCourse(detail);
    }
    setLoading(false);
  }, [params.id]);

  useEffect(() => { if (ready) load(); }, [ready, load]);

  async function addSection() {
    if (!newSectionTitle.trim() || !course) return;
    await api.post("/catalog/sections/", { course: course.id, title: newSectionTitle, order: (course.sections?.length || 0) + 1 });
    setNewSectionTitle("");
    load();
  }

  async function deleteSection(sectionId: number) {
    if (!confirm("Supprimer cette section et toutes ses vidéos ?")) return;
    await api.del(`/catalog/sections/${sectionId}/`);
    load();
  }

  async function deleteLesson(lessonId: number) {
    if (!confirm("Supprimer cette vidéo ?")) return;
    await api.del(`/catalog/lessons/${lessonId}/`);
    load();
  }

  async function addLessonByUrl(sectionId: number, title: string, duration: number, videoUrl: string, isPreview: boolean, subtitles: File | null, transcript: string) {
    if (subtitles) {
      const fd = new FormData();
      fd.append("section", String(sectionId)); fd.append("title", title); fd.append("duration_minutes", String(duration));
      fd.append("video_url", videoUrl); fd.append("order", "1"); fd.append("is_preview", String(isPreview));
      fd.append("subtitles_file", subtitles); fd.append("transcript", transcript);
      await apiUploadWithProgress("/catalog/lessons/", fd);
    } else {
      await api.post("/catalog/lessons/", { section: sectionId, title, duration_minutes: duration, video_url: videoUrl, order: 1, is_preview: isPreview, transcript });
    }
    load();
  }

  async function addLessonByFile(
    sectionId: number, title: string, file: File, isPreview: boolean, subtitles: File | null, transcript: string, offlineDownloadAllowed: boolean,
    onProgress: (percent: number) => void
  ) {
    const capabilities = await api.get<DirectUploadCapabilities>("/catalog/lessons/upload-capabilities/");
    if (capabilities.direct_multipart) {
      await uploadLessonVideoMultipart({
        sectionId, title, file, isPreview, subtitles, transcript, offlineDownloadAllowed, onProgress,
      });
    } else {
      // Développement local / stockage disque : conserver le chemin multipart HTTP classique.
      // La normalisation et ffprobe restent néanmoins asynchrones côté Celery.
      const fd = new FormData();
      fd.append("section", String(sectionId)); fd.append("title", title); fd.append("order", "1");
      fd.append("is_preview", String(isPreview)); fd.append("video_file", file); fd.append("transcript", transcript);
      fd.append("offline_download_allowed", String(offlineDownloadAllowed));
      if (subtitles) fd.append("subtitles_file", subtitles);
      await apiUploadWithProgress("/catalog/lessons/", fd, onProgress);
    }
    load();
  }

  async function addPdf(
    title: string, file: File, cover: File | null, isFreeSample: boolean,
    onProgress: (percent: number) => void
  ) {
    if (!course) return;
    const fd = new FormData();
    fd.append("course", String(course.id));
    fd.append("title", title);
    fd.append("is_free_sample", String(isFreeSample));
    fd.append("order", "1");
    fd.append("file", file);
    if (cover) fd.append("cover_image", cover);
    await apiUploadWithProgress("/catalog/pdf-resources/", fd, onProgress);
    load();
  }

  async function prepareStreaming(lessonId: number) {
    if (streamingBusy) return;
    setStreamingBusy(lessonId);
    try {
      await api.post(`/catalog/lessons/${lessonId}/prepare-streaming/`, {});
      const started = Date.now();
      while (Date.now() - started < 30 * 60 * 1000) {
        await new Promise((resolve) => window.setTimeout(resolve, 2500));
        const state = await api.get<{ status: string; detail?: string }>(`/catalog/lessons/${lessonId}/streaming-status/`);
        if (state.status === "ready") break;
        if (state.status === "failed") throw new Error(state.detail || "La préparation du streaming a échoué.");
      }
      await load();
    } catch (error) {
      alert(error instanceof Error ? error.message : "Impossible de préparer le streaming adaptatif.");
    } finally {
      setStreamingBusy(null);
    }
  }

  async function updateCompletionThreshold(value: number) {
    if (!course) return;
    const next = Math.max(50, Math.min(100, Math.round(value || 90)));
    await api.patch(`/catalog/courses/${course.slug}/`, { video_completion_threshold_percent: next });
    setCourse((current) => current ? { ...current, video_completion_threshold_percent: next } : current);
  }

  async function toggleOfflineLesson(lessonId: number, allowed: boolean) {
    await api.patch(`/catalog/lessons/${lessonId}/`, { offline_download_allowed: allowed });
    await load();
  }

  async function togglePublish() {
    if (!course) return;
    setPublishing(true);
    try {
      await api.patch(`/catalog/courses/${course.slug}/`, { published: !course.published });
      load();
    } finally {
      setPublishing(false);
    }
  }

  if (!ready) return <GuardScreen />;
  if (loading) return <div className="container-app py-20 text-center text-gray-500"><Loader2 className="mx-auto animate-spin" /></div>;
  if (!course) return <div className="container-app py-20 text-center text-gray-500">Cours introuvable.</div>;

  const canPublish = (course.sections?.length || 0) > 0 && course.total_lessons > 0;

  return (
    <div className="min-w-0">

      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold">{course.title}</h1>
          <p className="text-sm text-gray-500">
            {course.total_lessons} vidéos · {course.total_hours} h · {course.pdf_resources?.length || 0} PDF
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <label className="flex items-center gap-2 rounded-lg border border-gray-200 bg-white px-3 py-2 text-xs text-gray-600" title="Pour les vidéos hébergées par KalanPro, un saut dans la barre ne compte pas comme temps regardé.">
            <span>Validation vidéo</span>
            <input type="number" min={50} max={100} value={course.video_completion_threshold_percent || 90} onChange={(e) => setCourse((current) => current ? { ...current, video_completion_threshold_percent: Number(e.target.value) } : current)} onBlur={(e) => void updateCompletionThreshold(Number(e.target.value))} className="w-14 rounded border border-gray-200 px-1.5 py-1 text-center font-semibold" />
            <span>%</span>
          </label>
          {!canPublish && !course.published && (
            <span className="text-xs text-amber-600">Ajoutez au moins une vidéo avant de publier</span>
          )}
          <button onClick={togglePublish} disabled={publishing || (!canPublish && !course.published)}
            className={course.published ? "btn-outline" : "btn-primary disabled:cursor-not-allowed disabled:opacity-50"}>
            {course.published ? <EyeOff size={16} /> : <Eye size={16} />}
            {course.published ? "Dépublier" : "Publier le cours"}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-[1fr_340px]">
        <div className="flex flex-col gap-6">
          {(course.sections || []).map((section) => (
            <div key={section.id} className="card p-5">
              <div className="mb-3 flex items-center justify-between">
                <h3 className="font-bold">{section.title}</h3>
                <button onClick={() => deleteSection(section.id)} className="text-gray-400 hover:text-red-600">
                  <Trash2 size={16} />
                </button>
              </div>
              <div className="flex flex-col gap-2">
                {section.lessons.map((lesson) => (
                  <div key={lesson.id} className="flex items-center gap-2 rounded-lg border border-gray-100 px-3 py-2 text-sm">
                    <PlayCircle size={16} className="text-brand-600" />
                    <span className="flex-1">{lesson.title}</span>
                    {lesson.is_preview && <span className="badge bg-brand-50 text-brand-700">Aperçu gratuit</span>}
                    <span className="text-xs text-gray-400">{lesson.duration_minutes} min</span>
                    {lesson.video_file && (
                      <span className={`hidden rounded-full px-2 py-1 text-[10px] font-semibold sm:inline ${lesson.streaming_status === "ready" ? "bg-emerald-50 text-emerald-700" : lesson.streaming_status === "failed" ? "bg-red-50 text-red-600" : "bg-sky-50 text-sky-700"}`}>
                        {lesson.streaming_status === "ready" ? `HLS ${lesson.streaming_variants?.map((v) => `${v.height}p`).join("/") || "prêt"}` : lesson.streaming_status === "processing" ? "HLS en cours" : lesson.streaming_status === "failed" ? "HLS échoué" : "HLS en attente"}
                      </span>
                    )}
                    {lesson.video_file && (lesson.streaming_status === "failed" || lesson.streaming_status === "pending") && (
                      <button type="button" disabled={streamingBusy === lesson.id} onClick={() => void prepareStreaming(lesson.id)} className="rounded-md p-1.5 text-sky-700 hover:bg-sky-50 disabled:opacity-50" title="Préparer le streaming faible débit">
                        <RefreshCw size={14} className={streamingBusy === lesson.id ? "animate-spin" : ""} />
                      </button>
                    )}
                    {lesson.video_file && (
                      <label className="hidden items-center gap-1.5 text-[10px] font-semibold text-gray-500 md:flex" title="Génère une copie 360p téléchargeable par l'apprenant sur son appareil">
                        <input type="checkbox" checked={Boolean(lesson.offline_download_allowed)} onChange={(e) => void toggleOfflineLesson(lesson.id, e.target.checked)} />
                        Hors ligne
                      </label>
                    )}
                    {(lesson.video_file || lesson.video_url) && (
                      <button type="button" onClick={() => setVideoPreview({ src: (lesson.video_file || lesson.video_url) as string, title: lesson.title, subtitles: lesson.subtitles_file, hls: lesson.hls_url, audioHls: lesson.audio_hls_url, variants: lesson.streaming_variants, streamingStatus: lesson.streaming_status })}
                        className="font-semibold text-brand-700">Lire</button>
                    )}
                    <button onClick={() => deleteLesson(lesson.id)} className="text-gray-400 hover:text-red-600">
                      <Trash2 size={14} />
                    </button>
                  </div>
                ))}
              </div>
              <AddLessonForm
                onAddUrl={(title, duration, url, preview, subtitles, transcript) => addLessonByUrl(section.id, title, duration, url, preview, subtitles, transcript)}
                onAddFile={(title, file, preview, subtitles, transcript, offline, onProgress) => addLessonByFile(section.id, title, file, preview, subtitles, transcript, offline, onProgress)}
              />
            </div>
          ))}

          <div className="card flex items-center gap-2 p-4">
            <input
              value={newSectionTitle}
              onChange={(e) => setNewSectionTitle(e.target.value)}
              placeholder="Titre de la nouvelle section (ex: Introduction)"
              className="flex-1 rounded-lg border border-gray-200 px-3 py-2 text-sm"
            />
            <button onClick={addSection} className="btn-primary !py-2 !text-sm"><PlusCircle size={16} /> Ajouter</button>
          </div>
        </div>

        <div>
          <div className="card p-5">
            <h3 className="mb-3 flex items-center gap-2 font-bold"><FileText size={18} className="text-amber-600" /> PDF du cours</h3>
            <div className="flex flex-col gap-2">
              {(course.pdf_resources || []).map((pdf) => (
                <div key={pdf.id} className="flex items-center gap-2 rounded-lg border border-gray-100 px-3 py-2 text-sm">
                  {pdf.cover_image ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img loading="lazy" decoding="async" src={pdf.cover_image} alt="" className="h-9 w-7 rounded object-cover" />
                  ) : <FileText size={14} className="text-amber-600" />}
                  <span className="flex-1 line-clamp-1">{pdf.title} · {pdf.page_count} p.</span>
                  {pdf.is_free_sample && <span className="badge bg-brand-50 text-brand-700">Extrait</span>}
                  {pdf.file && <PdfViewer url={pdf.file} title={pdf.title} />}
                </div>
              ))}
            </div>
            <AddPdfForm onAdd={addPdf} />
          </div>
        </div>
      </div>
      {videoPreview && <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4" onClick={() => setVideoPreview(null)}><div className="w-full max-w-5xl overflow-hidden rounded-2xl bg-black" onClick={(e) => e.stopPropagation()}><div className="flex items-center justify-between bg-white px-4 py-3"><strong className="text-sm">{videoPreview.title}</strong><button type="button" onClick={() => setVideoPreview(null)} className="text-sm text-gray-500">Fermer</button></div><div className="aspect-video"><VideoPlayer src={videoPreview.src} hlsSrc={videoPreview.hls} audioHlsSrc={videoPreview.audioHls} streamingVariants={videoPreview.variants} streamingStatus={videoPreview.streamingStatus} title={videoPreview.title} subtitlesUrl={videoPreview.subtitles}/></div></div></div>}
    </div>
  );
}

async function extractVideoDurationFromUrl(url: string): Promise<number> {
  return new Promise((resolve, reject) => {
    const video = document.createElement("video");
    const timer = window.setTimeout(() => {
      video.src = "";
      reject(new Error("Impossible de lire les métadonnées de cette URL vidéo."));
    }, 12000);
    video.preload = "metadata";
    video.onloadedmetadata = () => {
      window.clearTimeout(timer);
      const seconds = video.duration;
      video.src = "";
      if (!Number.isFinite(seconds) || seconds <= 0) {
        reject(new Error("Durée vidéo invalide."));
        return;
      }
      resolve(Math.max(1, Math.ceil(seconds / 60)));
    };
    video.onerror = () => {
      window.clearTimeout(timer);
      reject(new Error("Impossible d'extraire la durée de cette URL vidéo."));
    };
    video.src = url;
  });
}

function AddLessonForm({
  onAddUrl, onAddFile,
}: {
  onAddUrl: (title: string, duration: number, url: string, preview: boolean, subtitles: File | null, transcript: string) => Promise<void>;
  onAddFile: (title: string, file: File, preview: boolean, subtitles: File | null, transcript: string, offlineDownloadAllowed: boolean, onProgress: (p: number) => void) => Promise<void>;
}) {
  const [mode, setMode] = useState<"file" | "url">("file");
  const [title, setTitle] = useState("");
  const [url, setUrl] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState(false);
  const [offlineDownload, setOfflineDownload] = useState(false);
  const [subtitles, setSubtitles] = useState<File | null>(null);
  const [transcript, setTranscript] = useState("");
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState("");
  const [fileInputKey, setFileInputKey] = useState(0);

  async function handleAdd() {
    setError("");
    if (!title.trim()) { setError("Le titre de la vidéo est obligatoire."); return; }
    if (mode === "file" && !file) { setError("Sélectionnez un fichier vidéo, ou basculez sur \"Lien externe\"."); return; }
    if (mode === "file" && file) {
      const ext = extensionOf(file.name);
      if (!ALLOWED_VIDEO_EXTENSIONS.includes(ext)) {
        setError(`Format vidéo non pris en charge (${ext || "sans extension"}). Utilisez MP4, WebM, MOV ou M4V.`);
        return;
      }
      if (file.size > MAX_VIDEO_UPLOAD_BYTES) {
        setError(`La vidéo fait ${(file.size / 1024 / 1024).toFixed(0)} Mo. La limite actuelle est de ${MAX_VIDEO_UPLOAD_MB} Mo.`);
        return;
      }
    }
    if (mode === "url" && !url.trim()) { setError("Indiquez un lien vidéo, ou basculez sur \"Uploader un fichier\"."); return; }

    setUploading(true);
    setProgress(0);
    try {
      if (mode === "file" && file) {
        await onAddFile(title, file, preview, subtitles, transcript, offlineDownload, setProgress);
      } else if (mode === "url") {
        const minutes = await extractVideoDurationFromUrl(url);
        await onAddUrl(title, minutes, url, preview, subtitles, transcript);
      }
      setTitle(""); setUrl(""); setFile(null); setPreview(false); setOfflineDownload(false); setSubtitles(null); setTranscript(""); setProgress(0);
      setFileInputKey((k) => k + 1); // réinitialise visuellement le champ fichier natif
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Erreur lors de l'ajout de la vidéo.");
    } finally {
      setUploading(false);
    }
  }

  return (
    <div className="mt-3 flex flex-col gap-2 border-t border-gray-100 pt-3">
      <div className="flex gap-2 text-xs">
        <button type="button" onClick={() => setMode("file")}
          className={`rounded-lg px-3 py-1.5 font-semibold ${mode === "file" ? "bg-brand-50 text-brand-700" : "bg-gray-100 text-gray-500"}`}>
          <Upload size={12} className="mr-1 inline" /> Uploader un fichier
        </button>
        <button type="button" onClick={() => setMode("url")}
          className={`rounded-lg px-3 py-1.5 font-semibold ${mode === "url" ? "bg-brand-50 text-brand-700" : "bg-gray-100 text-gray-500"}`}>
          <LinkIcon size={12} className="mr-1 inline" /> Lien externe
        </button>
      </div>

      <div>
        <label className="mb-0.5 block text-xs font-medium text-gray-500">Titre de la vidéo</label>
        <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Ex: Introduction aux hooks"
          className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm" />
        <p className="mt-1 text-xs text-gray-400">La durée est extraite automatiquement des métadonnées de la vidéo.</p>
      </div>

      {mode === "file" ? (
        <div>
          <label className="mb-0.5 block text-xs font-medium text-gray-500">Fichier vidéo</label>
          <input key={fileInputKey} type="file" accept="video/mp4,video/webm,video/quicktime,.mp4,.webm,.mov,.m4v" onChange={(e) => setFile(e.target.files?.[0] || null)}
            className="w-full rounded-lg border border-dashed border-gray-300 px-3 py-2 text-sm" />
          <p className="mt-1 text-xs text-gray-400">MP4, WebM, MOV ou M4V · jusqu’à {MAX_VIDEO_UPLOAD_MB >= 1024 ? `${(MAX_VIDEO_UPLOAD_MB / 1024).toFixed(MAX_VIDEO_UPLOAD_MB % 1024 ? 1 : 0)} Go` : `${MAX_VIDEO_UPLOAD_MB} Mo`}. KalanPro convertit automatiquement les codecs incompatibles en MP4 H.264/AAC.</p>
        </div>
      ) : (
        <div>
          <label className="mb-0.5 block text-xs font-medium text-gray-500">Lien vidéo</label>
          <input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://... (MP4/WebM direct, YouTube ou Vimeo)"
            className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm" />
          <p className="mt-1 text-xs text-gray-400">Pour une lecture immédiate, utilisez un fichier MP4/WebM direct. Les liens YouTube/Vimeo déjà enregistrés sont lus dans leur lecteur intégré.</p>
        </div>
      )}

      <div>
        <label className="mb-0.5 block text-xs font-medium text-gray-500">Sous-titres WebVTT (.vtt, optionnel)</label>
        <input key={`sub-${fileInputKey}`} type="file" accept=".vtt,text/vtt" onChange={(e) => setSubtitles(e.target.files?.[0] || null)} className="w-full rounded-lg border border-dashed border-gray-300 px-3 py-2 text-sm" />
      </div>
      <div>
        <label className="mb-0.5 block text-xs font-medium text-gray-500">Transcription (optionnelle)</label>
        <textarea value={transcript} onChange={(e) => setTranscript(e.target.value)} className="min-h-24 w-full rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="Transcription. Pour rendre les passages cliquables dans le lecteur : [00:00] Introduction, [01:25] Exemple…" />
      </div>
      <label className="flex items-center gap-2 text-xs text-gray-600">
        <input type="checkbox" checked={preview} onChange={(e) => setPreview(e.target.checked)} />
        Aperçu gratuit (consultable sans achat)
      </label>
      {mode === "file" && <label className="flex items-start gap-2 text-xs text-gray-600">
        <input className="mt-0.5" type="checkbox" checked={offlineDownload} onChange={(e) => setOfflineDownload(e.target.checked)} />
        <span><strong>Autoriser le hors connexion</strong><span className="block text-[10px] text-gray-400">KalanPro génère une copie 360p plafonnée en taille, enregistrable sur l'appareil de l'apprenant.</span></span>
      </label>}

      {uploading && mode === "file" && <UploadProgressBar percent={progress} label={progress >= 100 ? "Envoi terminé · vérification et conversion web si nécessaire…" : "Envoi de la vidéo…"} />}

      {error && (
        <p className="flex items-center gap-1 text-xs text-red-600"><AlertCircle size={12} /> {error}</p>
      )}

      <button onClick={handleAdd} disabled={uploading} className="btn-outline self-start !py-1.5 !text-xs">
        {uploading ? <Loader2 size={14} className="animate-spin" /> : <PlusCircle size={14} />}
        {uploading ? "Envoi en cours..." : "Ajouter la vidéo"}
      </button>
    </div>
  );
}

function AddPdfForm({
  onAdd,
}: {
  onAdd: (title: string, file: File, cover: File | null, isFreeSample: boolean, onProgress: (p: number) => void) => Promise<void>;
}) {
  const [title, setTitle] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [cover, setCover] = useState<File | null>(null);
  const [freeSample, setFreeSample] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState("");
  const [fileInputKey, setFileInputKey] = useState(0);

  async function handleAdd() {
    setError("");
    if (!title.trim()) { setError("Le titre du PDF est obligatoire."); return; }
    if (!file) { setError("Sélectionnez un fichier PDF."); return; }

    setUploading(true);
    setProgress(0);
    try {
      await onAdd(title, file, cover, freeSample, setProgress);
      setTitle(""); setFile(null); setCover(null); setFreeSample(false); setProgress(0);
      setFileInputKey((k) => k + 1);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Erreur lors de l'ajout du PDF.");
    } finally {
      setUploading(false);
    }
  }

  return (
    <div className="mt-3 flex flex-col gap-2 border-t border-gray-100 pt-3">
      <div>
        <label className="mb-0.5 block text-xs font-medium text-gray-500">Titre du PDF</label>
        <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Ex: Support de cours"
          className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm" />
      </div>
      <div>
        <label className="mb-0.5 block text-xs font-medium text-gray-500">Image de couverture (optionnelle)</label>
        <input key={`cover-${fileInputKey}`} type="file" accept="image/*" onChange={(e) => setCover(e.target.files?.[0] || null)}
          className="w-full rounded-lg border border-dashed border-gray-300 px-3 py-2 text-sm" />
      </div>
      <div>
        <label className="mb-0.5 block text-xs font-medium text-gray-500">Fichier PDF</label>
        <input key={`pdf-${fileInputKey}`} type="file" accept="application/pdf" onChange={(e) => setFile(e.target.files?.[0] || null)}
          className="w-full rounded-lg border border-dashed border-gray-300 px-3 py-2 text-sm" />
        <p className="mt-1 text-xs text-gray-400">Le nombre de pages est détecté automatiquement.</p>
      </div>
      <label className="flex items-center gap-2 text-xs text-gray-600">
        <input type="checkbox" checked={freeSample} onChange={(e) => setFreeSample(e.target.checked)} />
        Extrait gratuit (consultable sans achat)
      </label>

      {uploading && <UploadProgressBar percent={progress} label="Envoi du PDF..." />}

      {error && (
        <p className="flex items-center gap-1 text-xs text-red-600"><AlertCircle size={12} /> {error}</p>
      )}

      <button onClick={handleAdd} disabled={uploading} className="btn-outline self-start !py-1.5 !text-xs">
        {uploading ? <Loader2 size={14} className="animate-spin" /> : <PlusCircle size={14} />}
        {uploading ? "Envoi en cours..." : "Ajouter le PDF"}
      </button>
    </div>
  );
}

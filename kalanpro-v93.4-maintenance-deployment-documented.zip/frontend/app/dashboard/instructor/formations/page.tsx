"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { PlusCircle, Video, Users, Calendar, Loader2, AlertCircle, CheckCircle2, Trash2, BarChart3, Eye, EyeOff, Pencil, Search, ExternalLink, Hourglass } from "lucide-react";
import { api, ApiError } from "@/lib/api";
import { FormationSession, FormationWaitlistRow, InteractiveFormation } from "@/types";
import { useAuthGuard } from "@/hooks/useAuthGuard";
import GuardScreen from "@/components/ui/GuardScreen";

interface SessionReport {
  session: FormationSession & { formation_title?: string };
  organizers: { id: number; name: string; email: string; avatar?: string | null }[];
  participants: { user_id: number; name: string; email: string; role: string; total_seconds: number; first_join?: string | null; last_leave?: string | null }[];
}

interface WaitlistPayload {
  waiting: number;
  offered: number;
  results: FormationWaitlistRow[];
}

function formatSeconds(value:number){const total=Math.max(Math.floor(Number(value)||0),0);const h=Math.floor(total/3600);const m=Math.floor((total%3600)/60);const s=total%60;if(h>0)return `${h} h ${m} min`;if(m>0)return `${m} min ${s} s`;return `${s} s`;}

export default function InstructorFormationsPage() {
  const { ready } = useAuthGuard({ roles: ["instructor", "admin"], redirectTo: "/dashboard/instructor" });
  const [formations, setFormations] = useState<InteractiveFormation[]>([]);
  const [loading, setLoading] = useState(true);
  const [openId, setOpenId] = useState<number | null>(null);
  const [waitlistOpenId, setWaitlistOpenId] = useState<number | null>(null);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("all");
  const [message, setMessage] = useState("");
  const [report, setReport] = useState<SessionReport | null>(null);

  async function load() {
    const data = await api.get<InteractiveFormation[]>("/formations/my_formations/");
    setFormations(data);
    setLoading(false);
  }
  useEffect(() => { if (ready) load().catch(() => setLoading(false)); }, [ready]);

  const filtered = useMemo(() => formations.filter((f) => {
    const matchesStatus = status === "all" || (status === "published" ? f.published : !f.published);
    const q = search.trim().toLowerCase();
    return matchesStatus && (!q || `${f.title} ${f.description || ""}`.toLowerCase().includes(q));
  }), [formations, search, status]);

  async function addSession(formationId: number, sessionNumber: number, date: string, durationMinutes: number) {
    await api.post("/sessions/", {
      formation: formationId,
      session_number: sessionNumber,
      scheduled_at: date,
      duration_minutes: durationMinutes,
    });
    await load();
  }
  async function updateSession(id: number, date: string, durationMinutes: number) {
    await api.patch(`/sessions/${id}/`, {
      scheduled_at: date,
      duration_minutes: durationMinutes,
    });
    await load();
  }
  async function removeSession(id: number) {
    if (!confirm("Supprimer cette séance planifiée ?")) return;
    await api.del(`/sessions/${id}/`);
    await load();
  }
  async function togglePublished(formation: InteractiveFormation) {
    try { await api.patch(`/formations/${formation.slug}/`, { published: !formation.published }); await load(); }
    catch (e) { setMessage(e instanceof ApiError ? e.message : "Impossible de modifier la publication."); }
  }
  async function removeFormation(formation: InteractiveFormation) {
    if (!confirm(`Supprimer définitivement la formation « ${formation.title} » et son planning ?`)) return;
    try { await api.del(`/formations/${formation.slug}/`); await load(); setMessage("Formation supprimée."); }
    catch (e) { setMessage(e instanceof ApiError ? e.message : "Impossible de supprimer la formation."); }
  }
  async function showReport(id: number) {
    try { setReport(await api.get<SessionReport>(`/sessions/${id}/report/`)); }
    catch (e) { setMessage(e instanceof ApiError ? e.message : "Impossible de charger le rapport."); }
  }

  if (!ready) return <GuardScreen />;
  return <div className="min-w-0">
    <div className="mb-6 flex flex-wrap items-start justify-between gap-3"><div><h1 className="text-xl font-bold">Formations interactives</h1><p className="mt-1 text-sm text-gray-500">Gérez vos formations live, leurs informations, leur publication et leur planning.</p></div><Link href="/dashboard/instructor/formations/new" className="btn-primary !py-2 !text-sm"><PlusCircle size={16} /> Nouvelle formation</Link></div>
    <div className="card mb-4 flex flex-wrap gap-3 p-4"><div className="relative w-full flex-1 sm:min-w-[220px]"><Search size={15} className="absolute left-3 top-2.5 text-gray-400"/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Rechercher une formation" className="w-full rounded-lg border border-gray-200 py-2 pl-9 pr-3 text-sm"/></div><select value={status} onChange={e=>setStatus(e.target.value)} className="rounded-lg border border-gray-200 px-3 py-2 text-sm"><option value="all">Tous les statuts</option><option value="published">Publiées</option><option value="draft">Brouillons</option></select></div>
    {message && <div className="mb-4 rounded-xl bg-gray-50 p-3 text-sm text-gray-600">{message}</div>}
    {loading ? <div className="card p-8 text-center text-gray-500">Chargement...</div> : filtered.length === 0 ? <div className="card p-10 text-center text-gray-500">Aucune formation correspondante.</div> : <div className="flex flex-col gap-4">
      {filtered.map((f) => <div key={f.id} className="card p-5">
        <div className="flex flex-wrap items-center justify-between gap-3"><div className="w-full sm:min-w-[220px]"><div className="flex flex-wrap items-center gap-2"><p className="font-bold">{f.title}</p><span className={`badge ${f.published ? "bg-emerald-50 text-emerald-700" : "bg-gray-100 text-gray-600"}`}>{f.published ? "Publiée" : "Brouillon"}</span></div><p className="mt-1 text-xs text-gray-500">{f.num_sessions} séances · {f.session_duration_minutes} min/séance · <Users size={12} className="inline" /> {f.students_count}/{f.max_students} inscrits</p></div><div className="flex flex-wrap gap-2"><Link href={`/formations/${f.slug}`} target="_blank" className="btn-outline !py-1.5 !text-xs"><ExternalLink size={13}/> Voir</Link><Link href={`/dashboard/instructor/formations/${f.id}/edit`} className="btn-outline !py-1.5 !text-xs"><Pencil size={13}/> Modifier</Link><button onClick={() => togglePublished(f)} className="btn-outline !py-1.5 !text-xs">{f.published ? <EyeOff size={14} /> : <Eye size={14} />} {f.published ? "Dépublier" : "Publier"}</button><button onClick={() => setOpenId(openId === f.id ? null : f.id)} className="btn-outline !py-1.5 !text-xs"><Calendar size={14} /> Planning</button><button onClick={() => setWaitlistOpenId(waitlistOpenId === f.id ? null : f.id)} className="btn-outline !py-1.5 !text-xs"><Hourglass size={14} /> Attente {(f.waitlist_count || 0) + (f.waitlist_offered_count || 0)}</button><button onClick={()=>removeFormation(f)} className="rounded-lg border border-red-100 px-2.5 py-1.5 text-xs font-semibold text-red-600 hover:bg-red-50"><Trash2 size={13} className="mr-1 inline"/>Supprimer</button></div></div>
        {openId === f.id && <SessionManager formation={f} onAdd={addSession} onUpdate={updateSession} onDelete={removeSession} onReport={showReport} />}
        {waitlistOpenId === f.id && <WaitlistPanel formation={f} />}
      </div>)}
    </div>}
    {report && <ReportModal report={report} onClose={()=>setReport(null)} />}
  </div>;
}

function WaitlistPanel({ formation }: { formation: InteractiveFormation }) {
  const [data, setData] = useState<WaitlistPayload | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    setLoading(true);
    api.get<WaitlistPayload>(`/formations/${formation.slug}/waitlist/`)
      .then((payload) => { if (active) { setData(payload); setError(""); } })
      .catch((e) => { if (active) setError(e instanceof ApiError ? e.message : "Impossible de charger la liste d'attente."); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [formation.slug]);

  return <section className="mt-4 rounded-xl border border-amber-100 bg-amber-50/50 p-4">
    <div className="flex flex-wrap items-center justify-between gap-2"><div><h3 className="flex items-center gap-2 text-sm font-bold text-amber-900"><Hourglass size={16}/> Liste d'attente</h3><p className="mt-1 text-xs text-amber-800">{data ? `${data.waiting} en attente · ${data.offered} priorité(s) temporaire(s)` : "Ordre chronologique des demandes."}</p></div></div>
    {loading ? <p className="mt-3 flex items-center gap-2 text-xs text-gray-500"><Loader2 size={14} className="animate-spin"/> Chargement…</p> : error ? <p className="mt-3 text-xs text-red-600">{error}</p> : !data?.results.length ? <p className="mt-3 text-xs text-gray-500">Aucune personne dans la file.</p> : <div className="mt-3 overflow-x-auto"><table className="min-w-full text-left text-xs"><thead className="text-gray-500"><tr><th className="px-2 py-2">Priorité</th><th className="px-2 py-2">Apprenant</th><th className="px-2 py-2">État</th><th className="px-2 py-2">Depuis / échéance</th></tr></thead><tbody>{data.results.map((row) => <tr key={row.id} className="border-t border-amber-100"><td className="px-2 py-2 font-semibold">{row.position ? `#${row.position}` : "—"}</td><td className="px-2 py-2"><span className="font-semibold text-gray-800">{row.user.full_name}</span>{row.user.headline && <span className="block max-w-[260px] truncate text-gray-500">{row.user.headline}</span>}</td><td className="px-2 py-2"><WaitlistStatus status={row.status}/></td><td className="px-2 py-2 text-gray-500">{row.status === "offered" && row.offer_expires_at ? `Priorité jusqu'au ${new Date(row.offer_expires_at).toLocaleString("fr-FR", { dateStyle: "short", timeStyle: "short" })}` : new Date(row.created_at).toLocaleDateString("fr-FR")}</td></tr>)}</tbody></table></div>}
  </section>;
}

function WaitlistStatus({ status }: { status: FormationWaitlistRow["status"] }) {
  const labels: Record<FormationWaitlistRow["status"], string> = { waiting: "En attente", offered: "Place proposée", joined: "Inscrit", expired: "Offre expirée" };
  const classes: Record<FormationWaitlistRow["status"], string> = { waiting: "bg-amber-100 text-amber-800", offered: "bg-emerald-100 text-emerald-800", joined: "bg-blue-100 text-blue-800", expired: "bg-gray-100 text-gray-600" };
  return <span className={`badge ${classes[status]}`}>{labels[status]}</span>;
}

function toLocalDateTimeInput(value: string) {
  const date = new Date(value);
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60_000);
  return local.toISOString().slice(0, 16);
}

function SessionManager({ formation, onAdd, onUpdate, onDelete, onReport }: {
  formation: InteractiveFormation;
  onAdd: (formationId: number, sessionNumber: number, date: string, durationMinutes: number) => Promise<void>;
  onUpdate: (id: number, date: string, durationMinutes: number) => Promise<void>;
  onDelete: (id: number) => Promise<void>;
  onReport: (id: number) => Promise<void>;
}) {
  const sessions = formation.sessions || [];
  const next = sessions.reduce((m, s) => Math.max(m, s.session_number), 0) + 1;
  const [sessionNumber, setSessionNumber] = useState(String(next));
  const [date, setDate] = useState("");
  const [duration, setDuration] = useState(String(formation.session_duration_minutes));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editDate, setEditDate] = useState("");
  const [editDuration, setEditDuration] = useState("");

  useEffect(() => setSessionNumber(String(next)), [next]);

  async function submit() {
    setError("");
    setSuccess("");
    const durationMinutes = Number(duration);
    if (!date) { setError("Choisissez une date et une heure."); return; }
    if (!Number.isFinite(durationMinutes) || durationMinutes < 15 || durationMinutes > 480) {
      setError("La durée doit être comprise entre 15 et 480 minutes.");
      return;
    }
    setSaving(true);
    try {
      await onAdd(formation.id, Number(sessionNumber), new Date(date).toISOString(), durationMinutes);
      setDate("");
      setDuration(String(formation.session_duration_minutes));
      setSuccess("Séance planifiée.");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Erreur lors de la planification.");
    } finally { setSaving(false); }
  }

  function startEdit(session: FormationSession) {
    setError("");
    setSuccess("");
    setEditingId(session.id);
    setEditDate(toLocalDateTimeInput(session.scheduled_at));
    setEditDuration(String(session.duration_minutes));
  }

  async function saveEdit(session: FormationSession) {
    setError("");
    setSuccess("");
    const durationMinutes = Number(editDuration);
    if (!editDate) { setError("Choisissez une date et une heure."); return; }
    if (!Number.isFinite(durationMinutes) || durationMinutes < 15 || durationMinutes > 480) {
      setError("La durée doit être comprise entre 15 et 480 minutes.");
      return;
    }
    setSaving(true);
    try {
      await onUpdate(session.id, new Date(editDate).toISOString(), durationMinutes);
      setEditingId(null);
      setSuccess(`Planning de la séance ${session.session_number} mis à jour.`);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Impossible de modifier le planning.");
    } finally { setSaving(false); }
  }

  return (
    <div className="mt-4 border-t border-gray-100 pt-4">
      <div className="mb-4 max-h-80 space-y-2 overflow-y-auto pr-1">
        {sessions.map((session) => {
          const locked = Boolean(session.started_at || session.ended_at || session.completed);
          const editing = editingId === session.id;
          return (
            <div key={session.id} className="rounded-lg border border-gray-100 p-3 text-sm">
              <div className="flex flex-wrap items-center gap-3">
                <span className="badge bg-brand-50 text-brand-700">Séance {session.session_number}</span>
                <span>{new Date(session.scheduled_at).toLocaleString("fr-FR")}</span>
                <span className="text-gray-400">{session.duration_minutes} min prévues</span>
                {session.actual_duration_seconds > 0 && <span className="text-gray-500">· {formatSeconds(session.actual_duration_seconds)} réelles</span>}
                <div className="ml-auto flex items-center gap-2">
                  <Link href={`/live/session/${session.id}`} className="font-semibold text-brand-700"><Video size={14} className="inline" /> Salle</Link>
                  {!locked && <button onClick={() => editing ? setEditingId(null) : startEdit(session)} className="inline-flex items-center gap-1 text-gray-500 hover:text-brand-700" title="Modifier le planning"><Pencil size={15} /><span className="hidden sm:inline">Modifier</span></button>}
                  <button onClick={() => onReport(session.id)} className="text-gray-500" title="Rapport"><BarChart3 size={15} /></button>
                  <button onClick={() => onDelete(session.id)} className="text-gray-400 hover:text-red-600" title="Supprimer"><Trash2 size={15} /></button>
                </div>
              </div>
              {editing && (
                <div className="mt-3 grid grid-cols-1 gap-2 rounded-xl bg-gray-50 p-3 sm:grid-cols-[minmax(220px,1fr)_150px_auto_auto] sm:items-end">
                  <label className="text-xs font-medium text-gray-600">Date et heure
                    <input type="datetime-local" value={editDate} onChange={(e) => setEditDate(e.target.value)} className="mt-1 w-full rounded-lg border border-gray-200 bg-white px-3 py-2 text-sm" />
                  </label>
                  <label className="text-xs font-medium text-gray-600">Durée (min)
                    <input type="number" min={15} max={480} step={5} value={editDuration} onChange={(e) => setEditDuration(e.target.value)} className="mt-1 w-full rounded-lg border border-gray-200 bg-white px-3 py-2 text-sm" />
                  </label>
                  <button onClick={() => saveEdit(session)} disabled={saving} className="btn-primary !py-2 !text-xs">{saving ? <Loader2 size={14} className="animate-spin" /> : <CheckCircle2 size={14} />} Enregistrer</button>
                  <button onClick={() => setEditingId(null)} disabled={saving} className="btn-outline !py-2 !text-xs">Annuler</button>
                </div>
              )}
              {locked && <p className="mt-2 text-[11px] text-gray-400">Le planning est verrouillé car cette séance a déjà démarré.</p>}
            </div>
          );
        })}
        {sessions.length === 0 && <p className="text-xs text-gray-500">Aucune séance planifiée.</p>}
      </div>

      {sessions.length < formation.num_sessions && (
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-[110px_minmax(220px,1fr)_130px_auto]">
          <input aria-label="Numéro de séance" type="number" min={1} max={formation.num_sessions} value={sessionNumber} onChange={(e) => setSessionNumber(e.target.value)} className="rounded-lg border border-gray-200 px-3 py-2 text-sm" />
          <input aria-label="Date et heure" type="datetime-local" value={date} onChange={(e) => setDate(e.target.value)} className="rounded-lg border border-gray-200 px-3 py-2 text-sm" />
          <input aria-label="Durée en minutes" type="number" min={15} max={480} step={5} value={duration} onChange={(e) => setDuration(e.target.value)} className="rounded-lg border border-gray-200 px-3 py-2 text-sm" />
          <button onClick={submit} disabled={saving} className="btn-outline !py-2 !text-xs">{saving ? <Loader2 size={14} className="animate-spin" /> : <Calendar size={14} />} Planifier</button>
        </div>
      )}
      <p className="mt-2 text-xs text-gray-400">La salle vidéo KalanPro est créée automatiquement. La date, l'heure et la durée restent modifiables jusqu'au démarrage de la séance.</p>
      {error && <p className="mt-2 flex items-center gap-1 text-xs text-red-600"><AlertCircle size={12} /> {error}</p>}
      {success && <p className="mt-2 flex items-center gap-1 text-xs text-brand-700"><CheckCircle2 size={12} /> {success}</p>}
    </div>
  );
}

function ReportModal({report,onClose}:{report:SessionReport;onClose:()=>void}){return <div className="fixed inset-0 z-50 grid place-items-center bg-black/40 p-4" onClick={onClose}><div className="card max-h-[80vh] w-full max-w-2xl overflow-hidden" onClick={e=>e.stopPropagation()}><div className="flex items-start justify-between border-b border-gray-100 p-5"><div><h2 className="font-bold">Rapport de séance</h2><p className="text-xs text-gray-500">Séance {report.session.session_number} · {formatSeconds(report.session.actual_duration_seconds || 0)} réelles</p></div><button onClick={onClose} className="text-sm text-gray-500">Fermer</button></div><div className="max-h-[60vh] overflow-y-auto p-5"><div className="mb-3 flex flex-wrap gap-2">{report.organizers.map(o=><div key={o.id} className="flex items-center gap-2 rounded-xl bg-gray-50 px-3 py-2">{o.avatar?<img loading="lazy" decoding="async" src={o.avatar} alt="" className="h-8 w-8 rounded-full object-cover"/>:<span className="grid h-8 w-8 place-items-center rounded-full bg-brand-100 text-xs font-bold text-brand-700">{o.name.charAt(0)}</span>}<div><p className="text-xs font-semibold">{o.name}</p><p className="text-[10px] text-gray-400">{o.email}</p></div></div>)}</div><div className="space-y-2">{report.participants.map(p=><div key={`${p.user_id}-${p.role}`} className="flex items-center gap-3 rounded-xl bg-gray-50 p-3"><div className="min-w-0 flex-1"><p className="text-sm font-semibold">{p.name}</p><p className="text-[11px] text-gray-400">{p.email} · {p.role}</p></div><strong className="text-sm">{formatSeconds(p.total_seconds)}</strong></div>)}{!report.participants.length&&<p className="py-8 text-center text-sm text-gray-400">Aucune présence enregistrée.</p>}</div></div></div></div>}
